
package com.cg.tms.util;

import com.cg.tms.entity.Student;

public class StudentHelper {

	public StudentHelper() {
	}

	public boolean giveFeedback(Student student) {
		// TODO implement here
		return false;
	}

}